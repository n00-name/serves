function closePopup() {
    document.getElementById("errorPopup").style.display = "none";
}