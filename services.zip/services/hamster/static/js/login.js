function closePopup() {
    document.getElementById("errorPopup").style.display = "none";
}
localStorage.setItem("score", 0);