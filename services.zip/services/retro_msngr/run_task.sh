mkdir -p ./data/admin
sudo chown 33:33 -R ./data
sudo docker compose up --build -d
