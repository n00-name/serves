module.exports = {
	lintOnSave: false,
};
