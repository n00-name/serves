pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}
rootProject.name = "packmate"
