#!/bin/sh
cp -f /tmp/postgresql.conf /var/lib/postgresql/data/postgresql.conf
