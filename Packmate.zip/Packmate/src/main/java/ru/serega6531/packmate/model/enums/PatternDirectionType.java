package ru.serega6531.packmate.model.enums;

public enum PatternDirectionType {
    INPUT, OUTPUT, BOTH
}
