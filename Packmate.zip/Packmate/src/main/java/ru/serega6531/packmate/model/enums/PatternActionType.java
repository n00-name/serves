package ru.serega6531.packmate.model.enums;

public enum PatternActionType {
    FIND, IGNORE
}
