package ru.serega6531.packmate.model.pojo;

import lombok.Data;

@Data
public class PatternUpdateDto {

    private String name;
    private String color;

}
