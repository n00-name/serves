package ru.serega6531.packmate.model.enums;

public enum CaptureMode {

    LIVE, FILE, VIEW

}
