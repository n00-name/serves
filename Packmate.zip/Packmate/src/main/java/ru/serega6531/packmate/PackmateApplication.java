package ru.serega6531.packmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PackmateApplication {

    public static void main(String[] args) {
        SpringApplication.run(PackmateApplication.class, args);
    }

}
