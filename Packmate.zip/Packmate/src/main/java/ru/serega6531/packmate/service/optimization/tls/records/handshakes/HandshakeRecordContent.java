package ru.serega6531.packmate.service.optimization.tls.records.handshakes;

public interface HandshakeRecordContent {
}
