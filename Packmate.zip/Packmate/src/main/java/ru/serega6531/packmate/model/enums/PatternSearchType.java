package ru.serega6531.packmate.model.enums;

public enum PatternSearchType {
    REGEX, SUBSTRING, SUBBYTES
}
