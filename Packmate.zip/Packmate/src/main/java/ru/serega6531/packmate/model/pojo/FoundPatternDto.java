package ru.serega6531.packmate.model.pojo;

import lombok.Data;

@Data
public class FoundPatternDto {

    private int patternId;
    private int startPosition;
    private int endPosition;

}
