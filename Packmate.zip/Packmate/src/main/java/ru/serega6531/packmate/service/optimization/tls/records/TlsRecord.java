package ru.serega6531.packmate.service.optimization.tls.records;

import java.io.Serializable;

public interface TlsRecord extends Serializable {

}
