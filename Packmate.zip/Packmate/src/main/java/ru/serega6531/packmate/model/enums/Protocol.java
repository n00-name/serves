package ru.serega6531.packmate.model.enums;

public enum Protocol {
    TCP, UDP
}
